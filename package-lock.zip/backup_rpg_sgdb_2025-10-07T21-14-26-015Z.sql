
-- Estrutura: atributos
CREATE TABLE "atributos" (
  "id" int NOT NULL AUTO_INCREMENT,
  "forca" int DEFAULT NULL,
  "defesa" int DEFAULT NULL,
  "magia" int DEFAULT NULL,
  "agilidade" int DEFAULT NULL,
  "vida" int DEFAULT NULL,
  PRIMARY KEY ("id")
);

INSERT INTO `atributos` VALUES ('1', '15', '10', '2', '5', '120');
INSERT INTO `atributos` VALUES ('2', '10', '5', '3', '12', '100');
INSERT INTO `atributos` VALUES ('3', '12', '8', '6', '7', '110');
INSERT INTO `atributos` VALUES ('4', '8', '6', '2', '14', '90');
INSERT INTO `atributos` VALUES ('5', '10', '8', '0', '6', '90');
INSERT INTO `atributos` VALUES ('6', '15', '12', '2', '8', '120');
INSERT INTO `atributos` VALUES ('7', '6', '5', '0', '10', '80');
INSERT INTO `atributos` VALUES ('8', '20', '14', '0', '4', '160');

-- Estrutura: batalhas
CREATE TABLE "batalhas" (
  "id" int NOT NULL AUTO_INCREMENT,
  "session_id" varchar(64) NOT NULL,
  "personagem_id" int DEFAULT NULL,
  "monstro_id" int DEFAULT NULL,
  "hp_personagem" int DEFAULT '100',
  "hp_monstro" int DEFAULT '100',
  "ultima_acao" timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id")
);

INSERT INTO `batalhas` VALUES ('1', 'teste123', NULL, NULL, '100', '90', 'Tue Oct 07 2025 18:08:42 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('2', 'd436c3ee-dbda-4af6-a06c-f18ee7cdb2d2', NULL, NULL, '100', '29', 'Tue Oct 07 2025 18:22:53 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('3', 'ce77ce18-cf45-42c0-ba39-49233f3c7c53', NULL, NULL, '100', '60', 'Tue Oct 07 2025 18:25:49 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('4', '289fe302-341f-4541-ae72-4ac56efea1ff', NULL, NULL, '100', '-3', 'Tue Oct 07 2025 18:28:12 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('5', 'fc945c04-7a08-4c35-b319-51b93907738c', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:28:38 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('6', '7aaf4242-48d8-476b-bbd1-dff3bea89ee6', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:29:12 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('7', '053a3ef4-8bf2-48eb-ab8e-aeb81ee22e39', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:29:12 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('8', '09078148-c8df-4836-aef6-93df464d55ab', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:29:15 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('9', '0af89591-9281-4387-a5aa-1c5680e81156', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:30:09 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('10', '9fe83707-17b8-48e3-8b18-d48e4e42c180', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:30:49 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('11', '2ca03767-d942-497a-a290-bb58758acfa2', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:30:49 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('12', 'c3687799-347b-463d-90cc-d93443c1ded5', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:30:51 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('13', 'b025e7ef-c2fe-4a28-8190-f6d984adf2a7', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:31:55 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('14', '0d32454d-2708-4851-9fe7-cd8a4684b5af', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:34:24 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('15', '695fc9f2-77cd-42fe-a62e-597027902634', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:40:24 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('16', 'e29c34d0-2f41-4ca6-b024-84c928190550', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:40:24 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('17', 'fb6d6458-1df5-41c6-9a0b-75ba0939ef74', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:40:50 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('18', '3919ae8c-ad7f-4004-95a0-3b1f1fc87df3', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:41:56 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('19', '1fbd5abd-48be-415f-8a43-370f921e1508', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:42:10 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('20', '6af1469b-c771-4944-94be-3ab00f1949e3', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:44:20 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('21', '6765cd04-eede-4f9b-8666-d55c918988b8', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:46:18 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('22', 'a87c653d-0e1b-4590-b331-bc6580cebcf3', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:48:59 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('23', 'cb4c7081-5a34-414a-950d-535ad98fe684', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:49:06 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('24', '334e8745-b2ce-48ae-b388-fea8bbaa1a67', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:50:14 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('25', 'e39add55-ad05-4450-aa89-d7e4390e1eb6', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:50:22 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('26', 'dee5d0ac-d20d-45f8-aa2f-ec2be3a96626', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:50:57 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('27', 'fcb06d69-9d4e-47a0-b117-cf14298b301c', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:51:45 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('28', 'a50cbfb0-7030-4d16-9656-8740c31d2c9b', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:51:54 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('29', 'e7e62a29-bfdc-4ed9-b053-5367396c2565', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:51:58 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('30', 'de8b6b8f-bd16-4a42-9e04-f9fe47cf159a', NULL, NULL, '100', '100', 'Tue Oct 07 2025 18:56:32 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('31', 'ae9518f0-558d-4d7d-bec3-90c2b68e4b65', NULL, NULL, '100', '100', 'Tue Oct 07 2025 19:00:13 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('32', '0bcf6a64-1ee1-471c-95db-38b4a61315fb', NULL, NULL, '100', '100', 'Tue Oct 07 2025 19:00:27 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('33', 'b0b8c7cc-8423-4496-8024-de3c61084591', NULL, NULL, '100', '100', 'Tue Oct 07 2025 19:03:04 GMT-0300 (Horário Padrão de Brasília)');
INSERT INTO `batalhas` VALUES ('34', 'e1592ba0-805d-414c-b97b-fd7cd7c60217', NULL, NULL, '100', '100', 'Tue Oct 07 2025 19:05:59 GMT-0300 (Horário Padrão de Brasília)');

-- Estrutura: classes
CREATE TABLE "classes" (
  "id" int NOT NULL AUTO_INCREMENT,
  "nome" varchar(50) NOT NULL,
  "descricao" varchar(255) DEFAULT NULL,
  PRIMARY KEY ("id")
);

INSERT INTO `classes` VALUES ('1', 'Guerreiro', 'Alta força e defesa');
INSERT INTO `classes` VALUES ('2', 'Arqueiro', 'Alta agilidade e ataque à distância');
INSERT INTO `classes` VALUES ('3', 'Paladino', 'Equilibrado com magia de cura');
INSERT INTO `classes` VALUES ('4', 'Ladino', 'Alta agilidade e crítico');

-- Estrutura: monstros
CREATE TABLE "monstros" (
  "id" int NOT NULL AUTO_INCREMENT,
  "nome" varchar(50) NOT NULL,
  "atributo_id" int DEFAULT NULL,
  "criado_em" timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  "hp" int DEFAULT '100',
  PRIMARY KEY ("id"),
  KEY "atributo_id" ("atributo_id"),
  CONSTRAINT "monstros_ibfk_1" FOREIGN KEY ("atributo_id") REFERENCES "atributos" ("id")
);

INSERT INTO `monstros` VALUES ('1', 'Goblin', '5', 'Tue Oct 07 2025 16:35:22 GMT-0300 (Horário Padrão de Brasília)', '67');
INSERT INTO `monstros` VALUES ('2', 'Ogro', '6', 'Tue Oct 07 2025 16:35:22 GMT-0300 (Horário Padrão de Brasília)', '100');
INSERT INTO `monstros` VALUES ('3', 'Slime', '7', 'Tue Oct 07 2025 16:35:22 GMT-0300 (Horário Padrão de Brasília)', '100');
INSERT INTO `monstros` VALUES ('4', 'Dragão', '8', 'Tue Oct 07 2025 16:35:22 GMT-0300 (Horário Padrão de Brasília)', '100');

-- Estrutura: personagens
CREATE TABLE "personagens" (
  "id" int NOT NULL AUTO_INCREMENT,
  "nome" varchar(50) NOT NULL,
  "classe_id" int DEFAULT NULL,
  "atributo_id" int DEFAULT NULL,
  "experiencia" int DEFAULT '0',
  "nivel" int DEFAULT '1',
  "criado_em" timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  "hp" int DEFAULT '100',
  "classe" varchar(50) DEFAULT NULL,
  "ataque_base" int DEFAULT '10',
  "defesa_base" int DEFAULT '5',
  "hp_base" int DEFAULT '100',
  PRIMARY KEY ("id"),
  KEY "classe_id" ("classe_id"),
  KEY "atributo_id" ("atributo_id"),
  CONSTRAINT "personagens_ibfk_1" FOREIGN KEY ("classe_id") REFERENCES "classes" ("id"),
  CONSTRAINT "personagens_ibfk_2" FOREIGN KEY ("atributo_id") REFERENCES "atributos" ("id")
);

INSERT INTO `personagens` VALUES ('1', 'Arthas', '1', '1', '0', '1', 'Tue Oct 07 2025 16:35:21 GMT-0300 (Horário Padrão de Brasília)', '100', NULL, '10', '5', '100');
INSERT INTO `personagens` VALUES ('2', 'Legolas', '2', '2', '0', '1', 'Tue Oct 07 2025 16:35:21 GMT-0300 (Horário Padrão de Brasília)', '100', NULL, '10', '5', '100');
INSERT INTO `personagens` VALUES ('3', 'Uther', '3', '3', '0', '1', 'Tue Oct 07 2025 16:35:21 GMT-0300 (Horário Padrão de Brasília)', '100', NULL, '10', '5', '100');
INSERT INTO `personagens` VALUES ('4', 'Vex', '4', '4', '0', '1', 'Tue Oct 07 2025 16:35:21 GMT-0300 (Horário Padrão de Brasília)', '100', NULL, '10', '5', '100');
INSERT INTO `personagens` VALUES ('5', 'Arus', NULL, NULL, '0', '1', 'Tue Oct 07 2025 18:59:45 GMT-0300 (Horário Padrão de Brasília)', '100', 'Guerreiro', '15', '8', '120');
INSERT INTO `personagens` VALUES ('6', 'Lyria', NULL, NULL, '0', '1', 'Tue Oct 07 2025 18:59:45 GMT-0300 (Horário Padrão de Brasília)', '100', 'Maga', '20', '5', '90');
INSERT INTO `personagens` VALUES ('7', 'Kael', NULL, NULL, '0', '1', 'Tue Oct 07 2025 18:59:45 GMT-0300 (Horário Padrão de Brasília)', '100', 'Arqueiro', '17', '6', '100');

-- Estrutura: ranking_personagens
CREATE VIEW "ranking_personagens" AS select "p"."nome" AS "personagem",count(0) AS "vitorias" from ("batalhas" "b" join "personagens" "p" on(("b"."personagem_id" = "p"."id"))) where ("b"."vencedor" = 'personagem') group by "p"."id","p"."nome" order by "vitorias" desc;

-- Ignorando dados da VIEW ranking_personagens


-- Estrutura: sessoes
CREATE TABLE "sessoes" (
  "id" int NOT NULL AUTO_INCREMENT,
  "session_id" varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  "hp_personagem" int DEFAULT '100',
  "hp_monstro" int DEFAULT '100',
  "criado_em" timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  "personagem_id" int DEFAULT NULL,
  PRIMARY KEY ("id"),
  UNIQUE KEY "session_id" ("session_id"),
  KEY "personagem_id" ("personagem_id"),
  CONSTRAINT "sessoes_ibfk_1" FOREIGN KEY ("personagem_id") REFERENCES "personagens" ("id")
);

INSERT INTO `sessoes` VALUES ('1', 'c3687799-347b-463d-90cc-d93443c1ded5', '100', '19', 'Tue Oct 07 2025 18:30:52 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('2', 'b025e7ef-c2fe-4a28-8190-f6d984adf2a7', '100', '92', 'Tue Oct 07 2025 18:31:56 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('3', '0d32454d-2708-4851-9fe7-cd8a4684b5af', '59', '24', 'Tue Oct 07 2025 18:34:27 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('4', 'e29c34d0-2f41-4ca6-b024-84c928190550', '44', '0', 'Tue Oct 07 2025 18:40:25 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('5', 'fb6d6458-1df5-41c6-9a0b-75ba0939ef74', '99', '50', 'Tue Oct 07 2025 18:40:51 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('6', '3919ae8c-ad7f-4004-95a0-3b1f1fc87df3', '36', '0', 'Tue Oct 07 2025 18:41:58 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('7', '6af1469b-c771-4944-94be-3ab00f1949e3', '76', '56', 'Tue Oct 07 2025 18:44:20 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('8', 'teste123', '100', '94', 'Tue Oct 07 2025 18:46:10 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('9', '6765cd04-eede-4f9b-8666-d55c918988b8', '95', '88', 'Tue Oct 07 2025 18:46:18 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('10', 'a87c653d-0e1b-4590-b331-bc6580cebcf3', '100', '71', 'Tue Oct 07 2025 18:49:01 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('11', 'cb4c7081-5a34-414a-950d-535ad98fe684', '80', '0', 'Tue Oct 07 2025 18:49:07 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('12', '334e8745-b2ce-48ae-b388-fea8bbaa1a67', '57', '0', 'Tue Oct 07 2025 18:50:20 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('13', 'e39add55-ad05-4450-aa89-d7e4390e1eb6', '67', '0', 'Tue Oct 07 2025 18:50:26 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('14', 'dee5d0ac-d20d-45f8-aa2f-ec2be3a96626', '58', '0', 'Tue Oct 07 2025 18:50:58 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('15', 'fcb06d69-9d4e-47a0-b117-cf14298b301c', '57', '0', 'Tue Oct 07 2025 18:51:49 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('16', 'a50cbfb0-7030-4d16-9656-8740c31d2c9b', '71', '6', 'Tue Oct 07 2025 18:51:55 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('17', 'e7e62a29-bfdc-4ed9-b053-5367396c2565', '66', '0', 'Tue Oct 07 2025 18:51:59 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('18', 'de8b6b8f-bd16-4a42-9e04-f9fe47cf159a', '0', '100', 'Tue Oct 07 2025 18:56:32 GMT-0300 (Horário Padrão de Brasília)', '5');
INSERT INTO `sessoes` VALUES ('19', 'ae9518f0-558d-4d7d-bec3-90c2b68e4b65', '93', '27', 'Tue Oct 07 2025 19:00:14 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('20', '0bcf6a64-1ee1-471c-95db-38b4a61315fb', '88', '80', 'Tue Oct 07 2025 19:00:28 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('21', 'b0b8c7cc-8423-4496-8024-de3c61084591', '95', '100', 'Tue Oct 07 2025 19:03:05 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('22', 'e1592ba0-805d-414c-b97b-fd7cd7c60217', '100', '99', 'Tue Oct 07 2025 19:06:01 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('23', '97f099ec-5b1c-424e-8dd3-893cf0ebb06d', '100', '0', 'Tue Oct 07 2025 19:08:27 GMT-0300 (Horário Padrão de Brasília)', '1');
INSERT INTO `sessoes` VALUES ('24', '63709825-68fa-411b-ab40-c7c2948b977a', '100', '100', 'Tue Oct 07 2025 19:09:12 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('25', '507a5dcf-793e-4f49-afda-8145aec00f65', '100', '100', 'Tue Oct 07 2025 19:14:37 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('26', '0d2990c7-44f3-4e28-82ac-8571679a2f81', '32', '0', 'Tue Oct 07 2025 19:14:44 GMT-0300 (Horário Padrão de Brasília)', '7');
INSERT INTO `sessoes` VALUES ('27', 'e850a9a6-ab07-446c-85af-02abdce7fdab', '100', '100', 'Tue Oct 07 2025 19:16:18 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('28', 'd21b049e-ee9e-4b04-a31c-016478189cc9', '100', '100', 'Tue Oct 07 2025 19:16:23 GMT-0300 (Horário Padrão de Brasília)', '6');
INSERT INTO `sessoes` VALUES ('29', '42ebb4c0-9f4b-4170-811e-4e395d0825ba', '55', '79', 'Tue Oct 07 2025 19:16:29 GMT-0300 (Horário Padrão de Brasília)', '1');
INSERT INTO `sessoes` VALUES ('30', '6edce8ac-d6ab-4668-b3b1-76d7d672a4f0', '56', '100', 'Tue Oct 07 2025 19:16:56 GMT-0300 (Horário Padrão de Brasília)', '7');
INSERT INTO `sessoes` VALUES ('31', 'b74a2c8e-fdef-4dfd-b34b-ddbbd52ff725', '100', '100', 'Tue Oct 07 2025 19:17:23 GMT-0300 (Horário Padrão de Brasília)', '7');
INSERT INTO `sessoes` VALUES ('32', 'aeceade4-2b7a-4511-8105-fa1de18d7ebb', '85', '88', 'Tue Oct 07 2025 19:20:53 GMT-0300 (Horário Padrão de Brasília)', '6');
INSERT INTO `sessoes` VALUES ('33', '25783618-d13a-452d-a134-64d403134b6c', '0', '92', 'Tue Oct 07 2025 19:24:12 GMT-0300 (Horário Padrão de Brasília)', '1');
INSERT INTO `sessoes` VALUES ('34', '52abc2df-f85b-43ad-bdbe-a4383951b067', '100', '0', 'Tue Oct 07 2025 19:26:53 GMT-0300 (Horário Padrão de Brasília)', '1');
INSERT INTO `sessoes` VALUES ('35', '85044783-0bbd-44b4-ade3-3017344ec3d8', '72', '0', 'Tue Oct 07 2025 19:28:34 GMT-0300 (Horário Padrão de Brasília)', '3');
INSERT INTO `sessoes` VALUES ('36', '3ed504ed-d494-4991-87b5-727e51b3a872', '100', '0', 'Tue Oct 07 2025 19:31:00 GMT-0300 (Horário Padrão de Brasília)', '1');
INSERT INTO `sessoes` VALUES ('37', '47b06d16-3ed7-4a9c-97e7-ddcfdb3c883b', '100', '100', 'Tue Oct 07 2025 19:36:14 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('38', 'c72fe32b-39b5-4c12-b16b-beb2c68268fd', '100', '100', 'Tue Oct 07 2025 19:36:23 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('39', 'c3303fe3-b56c-4da0-abac-12c7b1a28b44', '100', '100', 'Tue Oct 07 2025 19:37:11 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('40', '45ec761c-406e-431e-94ff-2e31cfac5ff1', '100', '100', 'Tue Oct 07 2025 19:37:14 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('41', '46e28a53-ef53-4ca6-9f05-ecebf7df06e3', '100', '100', 'Tue Oct 07 2025 19:40:12 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('42', '8cde8424-fa13-4b3f-b0a6-2a08fc882573', '100', '100', 'Tue Oct 07 2025 19:40:19 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('43', 'bcca3715-531b-4aaf-9da9-b2a8371e1658', '100', '100', 'Tue Oct 07 2025 19:40:25 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('44', '12571dab-d2b1-4d60-9f32-56be8eada9fe', '100', '100', 'Tue Oct 07 2025 19:40:30 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('45', 'f13c3ebf-caa2-45f6-95c0-bbf979b9a741', '100', '100', 'Tue Oct 07 2025 19:40:32 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('46', 'a3bee872-6b9a-4629-85fc-ec2060325850', '100', '100', 'Tue Oct 07 2025 19:40:47 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('47', '8948198a-c1a9-419d-b2e1-3ec28b6775fd', '100', '100', 'Tue Oct 07 2025 19:40:58 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('48', '8533e144-722b-46e0-a572-68302637740d', '100', '100', 'Tue Oct 07 2025 19:41:54 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('49', '4cb3cffd-ba90-49c9-b5a8-ad54f7e13f5e', '100', '100', 'Tue Oct 07 2025 19:42:28 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('50', 'e9c0cc55-e3dd-46a1-8999-849f292a8444', '100', '100', 'Tue Oct 07 2025 19:42:37 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('51', '804e17ab-dfe3-4d24-bd3a-4288e29a6fbf', '100', '100', 'Tue Oct 07 2025 19:43:03 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('52', '68518003-c4f6-4316-a32f-3c5ddee4c30a', '100', '100', 'Tue Oct 07 2025 19:43:33 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('53', 'd0e58e6e-ee15-4f89-af03-bb2868b9e345', '100', '100', 'Tue Oct 07 2025 19:44:32 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('54', 'af085e5f-710b-4569-829f-46f0e502f097', '100', '100', 'Tue Oct 07 2025 19:44:36 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('55', 'da7e86fa-bc72-4d92-8702-4e22b9e150d4', '100', '100', 'Tue Oct 07 2025 19:44:37 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('56', '005f43f6-f573-465e-8e2a-9d04b7e83968', '100', '100', 'Tue Oct 07 2025 19:44:39 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('57', '55412d45-6ec6-4a74-9833-2b56a9a780da', '100', '94', 'Tue Oct 07 2025 19:49:43 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('58', '575ca91d-305b-4cec-88d1-61216da0f064', '100', '100', 'Tue Oct 07 2025 19:49:50 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('59', '21dbe245-0895-4f09-be44-77c991f59103', '100', '100', 'Tue Oct 07 2025 19:49:50 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('60', '42206e01-febd-4842-9943-7366e4f3a6c8', '100', '100', 'Tue Oct 07 2025 19:49:51 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('61', '4b943133-0069-415f-bc90-e0419cb8b00a', '100', '100', 'Tue Oct 07 2025 19:49:55 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('62', '7b6f4118-a594-4d25-8cda-d208a7a68183', '100', '100', 'Tue Oct 07 2025 19:53:55 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('63', '88049af8-12b0-4681-a76d-b7ba0696c245', '100', '100', 'Tue Oct 07 2025 19:54:37 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('64', '239c1094-cffa-4a28-b6b0-d42148ba96a7', '100', '100', 'Tue Oct 07 2025 19:55:08 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('65', '941bf833-9525-4841-badf-9347e3f0b0a5', '100', '100', 'Tue Oct 07 2025 19:55:30 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('66', '7eca881a-a039-49bf-9b98-ce727905536d', '100', '100', 'Tue Oct 07 2025 19:55:33 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('67', 'f06edf07-a541-4329-874e-340c8492a717', '100', '100', 'Tue Oct 07 2025 19:55:34 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('68', 'fcd4a6f8-0fde-42cd-bcc1-2460de9fff07', '100', '100', 'Tue Oct 07 2025 19:55:37 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('69', '0f6ebf2e-b528-46d8-9b9e-a7f6fc1bee24', '100', '100', 'Tue Oct 07 2025 19:55:40 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('70', '61c881dd-a8ca-45e7-8a22-3daaeb99fc91', '100', '100', 'Tue Oct 07 2025 19:55:41 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('71', '26dbeb8a-1dd2-4c2a-bb8d-8a493e78303a', '100', '100', 'Tue Oct 07 2025 19:59:06 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('72', 'd48d90e7-ee4d-4e92-88af-e3afd458105b', '0', '64', 'Tue Oct 07 2025 20:13:19 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('73', 'fc367c50-0333-4805-9ba7-8202ed5965ea', '100', '99', 'Tue Oct 07 2025 20:13:45 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('74', 'a2a40c36-93d7-45d1-ac24-a300c2a00f25', '100', '100', 'Tue Oct 07 2025 20:15:32 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('75', 'b6642c31-b5a5-45c7-ba09-fca400aa7383', '100', '100', 'Tue Oct 07 2025 20:15:34 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('76', '553e9125-e1cb-4abb-8cc6-bb3cba75bf20', '100', '100', 'Tue Oct 07 2025 20:15:41 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('77', 'a027c67b-b2da-4039-8584-85e120da26f6', '0', '4', 'Tue Oct 07 2025 20:15:44 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('78', '40ef0365-690a-4d71-bc63-d7f9a7571706', '0', '81', 'Tue Oct 07 2025 20:23:05 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('79', '22a4d0eb-4a68-484c-93d0-2d3f7d5188fd', '100', '100', 'Tue Oct 07 2025 20:23:34 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('80', '4a62881c-27ee-433f-8f6a-9c2be4572d84', '100', '100', 'Tue Oct 07 2025 20:30:26 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('81', 'e58ad135-e5a7-403f-a8ee-c2641a181364', '100', '100', 'Tue Oct 07 2025 20:34:10 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('82', '6cf8cb21-64da-4c6e-b4ab-339351a7fd7f', '100', '100', 'Tue Oct 07 2025 20:34:13 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('83', '6c406016-7f06-4e29-9a0c-48e33dd5b07c', '100', '100', 'Tue Oct 07 2025 20:34:54 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('84', 'ca45b528-4a63-4e04-987f-383451ca21c3', '100', '100', 'Tue Oct 07 2025 20:34:58 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('85', '0f813ee4-c318-467e-80d2-f1c554f6d563', '100', '100', 'Tue Oct 07 2025 20:35:16 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('86', '7eed0292-3de9-4b06-9902-fe0cad4059f7', '100', '100', 'Tue Oct 07 2025 20:39:24 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('87', 'bc7c27d1-4db9-4568-96db-2d1011f7b3e8', '0', '7', 'Tue Oct 07 2025 20:43:32 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('88', 'a14e427d-29e5-42fe-83d1-969194d3c8e0', '100', '100', 'Tue Oct 07 2025 20:43:46 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('89', 'c5fbef22-30a5-4ffd-add6-e03e094fd1d0', '100', '93', 'Tue Oct 07 2025 20:43:48 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('90', 'f0ef7c7c-1380-4d49-8e10-f6e7dfe9b8b5', '100', '100', 'Tue Oct 07 2025 20:44:08 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('91', '401fa542-c719-492b-ad5c-fa0863e77688', '0', '42', 'Tue Oct 07 2025 20:44:09 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('92', '939f0488-4720-4750-aefb-6c3eecda4129', '0', '0', 'Tue Oct 07 2025 20:46:52 GMT-0300 (Horário Padrão de Brasília)', NULL);
INSERT INTO `sessoes` VALUES ('93', 'f050cbb1-cc5d-46be-a8eb-bd80b0628046', '13', '0', 'Tue Oct 07 2025 20:47:49 GMT-0300 (Horário Padrão de Brasília)', NULL);

-- =======================================
-- ROTINAS ARMAZENADAS (Procedures/Functions)
-- =======================================


-- PROCEDURE: iniciar_batalha
CREATE DEFINER="avnadmin"@"%" PROCEDURE "iniciar_batalha"()
BEGIN
    DECLARE personagem_id INT;
    DECLARE monstro_id INT;

    SELECT id INTO personagem_id FROM personagens ORDER BY RAND() LIMIT 1;
    SELECT id INTO monstro_id FROM monstros ORDER BY RAND() LIMIT 1;

    SELECT personagem_id, monstro_id, 'Batalha iniciada!' AS mensagem;
END;


-- PROCEDURE: realizar_acao
CREATE DEFINER="avnadmin"@"%" PROCEDURE "realizar_acao"(
    IN p_personagem_id INT,
    IN p_monstro_id INT,
    IN p_acao VARCHAR(20)
)
BEGIN
    DECLARE dano INT DEFAULT 0;
    DECLARE cura INT DEFAULT 0;
    DECLARE hp_personagem INT DEFAULT 0;
    DECLARE hp_monstro INT DEFAULT 0;

    -- Carrega HPs
    SELECT hp INTO hp_personagem FROM personagens WHERE id = p_personagem_id;
    SELECT hp INTO hp_monstro FROM monstros WHERE id = p_monstro_id;

    -- Ação do jogador
    IF p_acao = 'atacar' THEN
        SET dano = FLOOR(RAND() * 15) + 5;
        UPDATE monstros SET hp = GREATEST(0, hp - dano) WHERE id = p_monstro_id;
        SELECT CONCAT('Você atacou e causou ', dano, ' de dano!') AS resultado;

    ELSEIF p_acao = 'bloquear' THEN
        SET dano = FLOOR(RAND() * 10);
        SELECT CONCAT('Você bloqueou ', dano, ' de dano do inimigo!') AS resultado;

    ELSEIF p_acao = 'curar' THEN
        SET cura = FLOOR(RAND() * 12) + 3;
        UPDATE personagens SET hp = LEAST(100, hp + cura) WHERE id = p_personagem_id;
        SELECT CONCAT('Você se curou em ', cura, ' pontos de vida!') AS resultado;

    ELSE
        SELECT 'Ação inválida!' AS resultado;
    END IF;
END;


-- PROCEDURE: realizar_acao_por_sessao
CREATE DEFINER="avnadmin"@"%" PROCEDURE "realizar_acao_por_sessao"(
    IN p_session_id VARCHAR(64),
    IN p_acao VARCHAR(20)
)
BEGIN
    DECLARE v_hp_personagem INT DEFAULT 100;
    DECLARE v_hp_monstro INT DEFAULT 100;
    DECLARE v_dano_personagem INT DEFAULT 0;
    DECLARE v_dano_monstro INT DEFAULT 0;
    DECLARE v_resultado VARCHAR(255);
    DECLARE v_msg_final VARCHAR(255) DEFAULT '';

    -- busca HPs atuais
    SELECT hp_personagem, hp_monstro
    INTO v_hp_personagem, v_hp_monstro
    FROM sessoes
    WHERE session_id = p_session_id;

    -- ação do jogador
    IF p_acao = 'atacar' THEN
        SET v_dano_personagem = FLOOR(RAND() * 20) + 10; -- 10–30
        SET v_hp_monstro = GREATEST(v_hp_monstro - v_dano_personagem, 0);
        SET v_resultado = CONCAT('Você atacou e causou ', v_dano_personagem, ' de dano!');
    ELSEIF p_acao = 'bloquear' THEN
        SET v_resultado = 'Você se protegeu do ataque!';
    ELSEIF p_acao = 'curar' THEN
        SET v_hp_personagem = LEAST(v_hp_personagem + (FLOOR(RAND() * 15) + 5), 100);
        SET v_resultado = CONCAT('Você se curou e agora tem ', v_hp_personagem, ' de HP.');
    ELSE
        SET v_resultado = 'Ação inválida.';
    END IF;

    -- verifica se o monstro morreu antes de contra-atacar
    IF v_hp_monstro <= 0 THEN
        SET v_msg_final = '🏆 Você derrotou o monstro!';
    ELSE
        -- ataque do monstro
        SET v_dano_monstro = FLOOR(RAND() * 18) + 12; -- 12–30
        SET v_hp_personagem = GREATEST(v_hp_personagem - v_dano_monstro, 0);
        SET v_resultado = CONCAT(v_resultado, ' O monstro atacou e causou ', v_dano_monstro, ' de dano!');

        -- verifica se o jogador morreu depois do ataque
        IF v_hp_personagem <= 0 THEN
            SET v_msg_final = '💀 Você foi derrotado pelo monstro!';
        END IF;
    END IF;

    -- se alguém morreu, reinicia os HPs
    IF v_hp_personagem <= 0 OR v_hp_monstro <= 0 THEN
        SET v_resultado = CONCAT(v_resultado, ' ', v_msg_final, ' Uma nova batalha começou!');
        SET v_hp_personagem = 100;
        SET v_hp_monstro = 100;
    END IF;

    -- salva estado atualizado
    UPDATE sessoes
    SET hp_personagem = v_hp_personagem,
        hp_monstro = v_hp_monstro
    WHERE session_id = p_session_id;

    -- retorna resultado
    SELECT
        v_resultado AS resultado,
        v_hp_personagem AS hp_personagem,
        v_hp_monstro AS hp_monstro;
END;


-- PROCEDURE: realizar_batalha
CREATE DEFINER="avnadmin"@"%" PROCEDURE "realizar_batalha"(IN p_personagem_id INT, IN p_monstro_id INT)
BEGIN
    DECLARE v_hp_personagem INT;
    DECLARE v_hp_monstro INT;
    DECLARE v_forca_personagem INT;
    DECLARE v_forca_monstro INT;
    DECLARE v_defesa_personagem INT;
    DECLARE v_defesa_monstro INT;
    DECLARE v_magia_personagem INT;
    DECLARE v_agilidade_personagem INT;
    DECLARE v_agilidade_monstro INT;
    DECLARE v_dano_personagem FLOAT;
    DECLARE v_dano_monstro FLOAT;
    DECLARE v_vencedor VARCHAR(20);

    -- Atributos
    SELECT a.forca, a.defesa, a.magia, a.agilidade, a.vida
      INTO v_forca_personagem, v_defesa_personagem, v_magia_personagem, v_agilidade_personagem, v_hp_personagem
      FROM atributos a
      JOIN personagens p ON p.atributo_id = a.id
     WHERE p.id = p_personagem_id;

    SELECT a.forca, a.defesa, a.magia, a.agilidade, a.vida
      INTO v_forca_monstro, v_defesa_monstro, v_magia_personagem, v_agilidade_monstro, v_hp_monstro
      FROM atributos a
      JOIN monstros m ON m.atributo_id = a.id
     WHERE m.id = p_monstro_id;

    -- Loop de batalha
    batalha_loop: WHILE v_hp_personagem > 0 AND v_hp_monstro > 0 DO
        -- dano aleatório (±15%)
        SET v_dano_personagem = (v_forca_personagem - v_defesa_monstro / 2) * (0.85 + RAND() * 0.30);
        SET v_dano_monstro = (v_forca_monstro - v_defesa_personagem / 2) * (0.85 + RAND() * 0.30);

        -- prioridade: quem tem mais agilidade ataca primeiro
        IF v_agilidade_personagem >= v_agilidade_monstro THEN
            SET v_hp_monstro = v_hp_monstro - v_dano_personagem;
            IF v_hp_monstro <= 0 THEN
                SET v_vencedor = 'personagem';
                LEAVE batalha_loop;
            END IF;

            SET v_hp_personagem = v_hp_personagem - v_dano_monstro;
            IF v_hp_personagem <= 0 THEN
                SET v_vencedor = 'monstro';
                LEAVE batalha_loop;
            END IF;
        ELSE
            SET v_hp_personagem = v_hp_personagem - v_dano_monstro;
            IF v_hp_personagem <= 0 THEN
                SET v_vencedor = 'monstro';
                LEAVE batalha_loop;
            END IF;

            SET v_hp_monstro = v_hp_monstro - v_dano_personagem;
            IF v_hp_monstro <= 0 THEN
                SET v_vencedor = 'personagem';
                LEAVE batalha_loop;
            END IF;
        END IF;
    END WHILE batalha_loop;

    INSERT INTO batalhas (personagem_id, monstro_id, vencedor, hp_final_personagem, hp_final_monstro)
    VALUES (p_personagem_id, p_monstro_id, v_vencedor, v_hp_personagem, v_hp_monstro);

    SELECT v_vencedor AS vencedor, v_hp_personagem AS hp_final_personagem, v_hp_monstro AS hp_final_monstro;
END;


-- PROCEDURE: simular_batalhas
CREATE DEFINER="avnadmin"@"%" PROCEDURE "simular_batalhas"(IN num INT)
BEGIN
    DECLARE i INT DEFAULT 0;
    DECLARE p INT;
    DECLARE m INT;

    WHILE i < num DO
        SET p = FLOOR(1 + RAND() * (SELECT COUNT(*) FROM personagens));
        SET m = FLOOR(1 + RAND() * (SELECT COUNT(*) FROM monstros));
        CALL realizar_batalha(p, m);
        SET i = i + 1;
    END WHILE;
END;
