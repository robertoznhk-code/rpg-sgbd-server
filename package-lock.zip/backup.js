import mysql from "mysql2/promise";
import fs from "fs";
import dotenv from "dotenv";
import path from "path";

dotenv.config();

console.log("🔗 Conectando ao banco de dados Aiven com certificado...");

try {
  const certPath = path.resolve("cert/ca.pem");
  if (!fs.existsSync(certPath)) {
    throw new Error(`Certificado não encontrado em: ${certPath}`);
  }

  const connection = await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || 3306,
    ssl: {
      ca: fs.readFileSync(certPath),
      rejectUnauthorized: true,
    },
  });

  console.log("✅ Conectado com sucesso! Gerando backup completo...");

  const dumpLines = [];

  // ======================
  // 📦 Exportar tabelas e views
  // ======================
  const [tables] = await connection.query(
    "SHOW FULL TABLES WHERE Table_Type = 'BASE TABLE' OR Table_Type = 'VIEW'"
  );

  for (const row of tables) {
    const tableName = Object.values(row)[0];
    console.log(`📦 Exportando tabela/view: ${tableName}`);

    try {
      const [createTable] = await connection.query(`SHOW CREATE TABLE \`${tableName}\``);
      const createSQL = createTable[0]["Create Table"] || createTable[0]["Create View"];

      dumpLines.push(`\n-- Estrutura: ${tableName}`);
      dumpLines.push(createSQL + ";\n");

      if (createSQL.includes("VIEW")) {
        dumpLines.push(`-- Ignorando dados da VIEW ${tableName}\n`);
        continue;
      }

      const [rows] = await connection.query(`SELECT * FROM \`${tableName}\``);
      for (const r of rows) {
        const values = Object.values(r)
          .map((v) => (v === null ? "NULL" : `'${String(v).replace(/'/g, "''")}'`))
          .join(", ");
        dumpLines.push(`INSERT INTO \`${tableName}\` VALUES (${values});`);
      }
    } catch (err) {
      console.warn(`⚠️ Pulando tabela/view problemática: ${tableName} (${err.message})`);
      continue;
    }
  }

  // ======================
  // 🧠 Exportar Procedures e Functions (MySQL 8+)
  // ======================
  dumpLines.push("\n-- =======================================");
  dumpLines.push("-- ROTINAS ARMAZENADAS (Procedures/Functions)");
  dumpLines.push("-- =======================================\n");

  const [routines] = await connection.query(
    "SELECT ROUTINE_NAME, ROUTINE_TYPE FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA = ?",
    [process.env.DB_NAME]
  );

  for (const r of routines) {
    console.log(`🧠 Exportando ${r.ROUTINE_TYPE}: ${r.ROUTINE_NAME}`);
    try {
      const [def] = await connection.query(
        `SHOW CREATE ${r.ROUTINE_TYPE} \`${r.ROUTINE_NAME}\``
      );
      const key = `Create ${r.ROUTINE_TYPE.charAt(0).toUpperCase() + r.ROUTINE_TYPE.slice(1).toLowerCase()}`;
      const createSQL = def[0]?.[key];

      if (createSQL) {
        dumpLines.push(`\n-- ${r.ROUTINE_TYPE}: ${r.ROUTINE_NAME}`);
        dumpLines.push(createSQL + ";\n");
      } else {
        dumpLines.push(`\n-- ${r.ROUTINE_TYPE}: ${r.ROUTINE_NAME} (corpo não disponível)\n`);
      }
    } catch (err) {
      dumpLines.push(`\n-- ${r.ROUTINE_TYPE}: ${r.ROUTINE_NAME} (falha ao exportar: ${err.message})\n`);
    }
  }

  // ======================
  // 💾 Salvar arquivo final
  // ======================
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const dumpPath = path.resolve(`backup_rpg_sgdb_${timestamp}.sql`);
  fs.writeFileSync(dumpPath, dumpLines.join("\n"), "utf8");

  console.log(`\n💾 Backup concluído com sucesso!`);
  console.log(`📂 Arquivo salvo em: ${dumpPath}`);

  await connection.end();
} catch (err) {
  console.error("❌ Erro ao gerar backup:");
  console.error(err.message);
}
